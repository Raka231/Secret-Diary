<?php

    $link = mysqli_connect("localhost","id10313675_secretdiary","Raka@123","id10313675_secretdiary");
        
        if (mysqli_connect_error()) {
            
            die ("Database Connection Error");
            
        }

?>